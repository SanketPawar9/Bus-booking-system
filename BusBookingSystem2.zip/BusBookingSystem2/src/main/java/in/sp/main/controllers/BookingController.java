package in.sp.main.controllers;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.sp.main.entitys.Booking;
import in.sp.main.entitys.Route;
import in.sp.main.entitys.User;

import in.sp.main.services.UserService;
import jakarta.servlet.http.HttpSession;
import in.sp.main.services.BookingService;
import in.sp.main.services.RouteService;
import org.springframework.web.bind.annotation.RequestBody;


@Controller
public class BookingController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private BookingService bookingService; 
	
	@Autowired
	private RouteService routeService;
	
	LocalDate currentDate=LocalDate.now();
	
	public void setBookingList(int id,LocalDate date,Model model) {
		Route route = routeService.getRouteById(id);
        if (route == null) {
            System.out.println("No route found for ID: " + id); // Debugging log
            model.addAttribute("error", "No route found.");
            
        }
        
        List<Booking> bookingList=bookingService.getBookingByDate(date, route);
//        for (Booking booking : bookingList) {
//			System.out.println(booking.getSeatNumber());
//			System.out.println(booking.getBookingDate());
//			System.out.println(booking.getUser().getName());
//		}
        model.addAttribute("bookingList",bookingList);
        model.addAttribute("route", route);
	}
	
	@GetMapping("/showBookings")
    public String showBookings(@RequestParam("routeId") int routeId, Model model) {
        System.out.println("Received route ID: " + routeId); // Debugging log
        
        setBookingList(routeId, currentDate, model);
        model.addAttribute("id", routeId);
        model.addAttribute("date",currentDate);
        
        return "showBookings";
    }
	
	@PostMapping("/adduserform")
	public String postMethodName(
	    @RequestParam("seatNumber") int seatNumber,  // Seat number from the form
	    @RequestParam("route") int id,                  // Route ID from the form
	    @ModelAttribute("user") User user,           // User details (if needed)
	    @ModelAttribute("booking") Booking booking,   // Booking details (if needed)
	    Model model
	) {
	  
	   User user1=userService.addUser(user);
	    if (user1!=null) {
			booking.setUser(user1);
			Booking  booking1=bookingService.addBooking(booking);
			if (booking1!=null) {
//				model.addAttribute("booking",booking1);
				setBookingList(id, booking1.getBookingDate(), model);
				
				model.addAttribute("success","Bus book succesfully");
				model.addAttribute("date",booking1.getBookingDate());
			}
		}
	    
	 
	    return "showBookings";  // Redirect to a confirmation/profile page
	}
	@PostMapping("/applydateform")
	public String applydateform(
			@RequestParam("date") 
	        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
			@ModelAttribute("route") Route route,Model model)
	
	{
		
		List<Booking> bookingList=bookingService.getBookingByDate(date, route);
		model.addAttribute("bookingList",bookingList);
		model.addAttribute("date",date);
		
		model.addAttribute("route", route);
		return "showBookings";
	}
	
	@GetMapping("/cancelSeat")
	public String getMethodName(@RequestParam("bookingId") Booking booking,
			@RequestParam("route") Route route,Model model) {
		
//		System.out.println(booking);
//		System.out.println(booking.getBookingDate());
//		System.out.println(route);
		
		boolean status= bookingService.deleteBooking(booking);
		if (status) {
			model.addAttribute("success", "booking canceled succesfully");
			model.addAttribute("date",booking.getBookingDate());
		}
		else {
			model.addAttribute("error","booking not canceled succesfully some error occures");
		}
		setBookingList(route.getId(), booking.getBookingDate(), model);
		
		return "showBookings";
	}
	@GetMapping("/allotSeat")
	public String allotSeat(@RequestParam("userId") User user,
							@RequestParam("seatNumber") int seatNumber,
							@RequestParam("routeId") Route route,
							@RequestParam("bookingDate") Date date,
							Model model) {
		model.addAttribute(user);
		model.addAttribute(route);
		model.addAttribute("seatNumber",seatNumber);
		model.addAttribute("date",date);
		return "addOldUserBooking";
	}
	@PostMapping("/addOldUserBookingForm")
	public String addOldUserBookingForm(@RequestBody String entity) {
		
		return "showBookings";
	}
	
	@GetMapping("/finallySeatBooked")
	public String finallySeatBooked(@RequestParam("userId") User user,
			@RequestParam("seatNumber") String seatNumber,
			@RequestParam("routeId") Route route,
			@RequestParam("date") 
	        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
			Model model) {
		
		//System.out.println(session+"=====ddd===d");
		Booking booking=new Booking();
		booking.setBookingDate(date);
		booking.setRoute(route);
		booking.setSeatNumber(seatNumber);
		booking.setUser(user);
		Booking booking1 = bookingService.addBooking(booking);
		if (booking1!=null) {
			model.addAttribute("success","Bus booked successfully");
		}
		else {
			model.addAttribute("error","Bus not booked error occurs");
		}
		
		List<Booking> bookingList = bookingService.findUserBookings(user);
		model.addAttribute("bookingList",bookingList);
		return "userBookings";
	}
	
	

}
