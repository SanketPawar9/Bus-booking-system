package in.sp.main.controllers;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.sp.main.entitys.Route;
import in.sp.main.services.RouteService;

@Controller
public class HomeController {

	
	@Autowired
	private RouteService routeService;
	
	LocalDate currentDate=LocalDate.now();
	@GetMapping("/")
    public String indexPage(Model model) {
		
		List<Route> routes = routeService.getAllActiveData();
		List<String> sourceList=new ArrayList<>();
		List<String> destinationList=new ArrayList<>();
		
		for (Route route : routes) {
		    // Normalize the source string to remove spaces around '→'
		    String source = route.getSource().replaceAll("\\s*→\\s*", "→");
		    String sourceWord = "";  // Initialize outside loop
		    String destination = route.getDestination().replaceAll("\\s*→\\s*", "→");
		    String destinationWord = "";
		    
		    for (int i = 0; i < source.length(); i++) {  
		        if (source.charAt(i) == '→') {
		            
		                System.out.println(sourceWord); 
		                sourceList.add(sourceWord);
		            
		            sourceWord = "";  // Reset word for the next segment
		        } else {
		        	sourceWord += source.charAt(i);  
		        }
		    }

		    // Print the last word (if it exists) **BEFORE LOOP ENDS**
		    if (!sourceWord.isEmpty()) {
		        System.out.println(sourceWord);
		        sourceList.add(sourceWord);
		    }
		   
		    for (int i = 0; i < destination.length(); i++) {  
		        if (destination.charAt(i) == '→') {
		           
		                System.out.println(destinationWord);
		                destinationList.add(destinationWord);
		                destinationWord = "";  // Reset word for the next segment
		        } else {
		        	destinationWord += destination.charAt(i);  
		        }
		    }

		   
		    if (!destinationWord.isEmpty()) {
		        System.out.println(destinationWord);
		        destinationList.add(destinationWord);
		    }
		    System.out.println("=============================");
		    
		}
		Set<String> sourceListUnique=new LinkedHashSet<>(sourceList);
		Set<String> destinationListUnique=new LinkedHashSet<>(destinationList);
		model.addAttribute("sourceList",sourceListUnique);
		model.addAttribute("destinationList",destinationListUnique);
		model.addAttribute("routes",routes);
		model.addAttribute("date",currentDate);
		return "index";
	}
	@GetMapping("/serchSourceDestination")
	public String serchSourceDestination(@RequestParam("source") String inputSource,
										@RequestParam("destination") String inputDestination,
										@RequestParam("date") 
								        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
										Model model)
	{
		List<Route> routes = routeService.getAllActiveData();
		List<Route> routesList=new ArrayList<>();
		
		
		for (Route route : routes) {
		
			if (route.getSource().contains(inputSource)&&route.getDestination().contains(inputDestination)) {
				
				routesList.add(route);
			} 
			
		}
		model.addAttribute("routesList", routesList);
		model.addAttribute("source", inputSource);
		model.addAttribute("destination", inputDestination);
		model.addAttribute("date",date);
		indexPage(model);
		
		return "index";
	}
	
}
