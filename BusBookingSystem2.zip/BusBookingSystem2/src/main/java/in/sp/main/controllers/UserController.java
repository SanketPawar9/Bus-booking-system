package in.sp.main.controllers;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import in.sp.main.entitys.Admin;
import in.sp.main.entitys.Booking;
import in.sp.main.entitys.Route;
import in.sp.main.entitys.User;
import in.sp.main.services.RouteService;
import in.sp.main.services.UserService;
import jakarta.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;




@Controller
public class UserController {

    @Autowired
    private RouteService routeService;
    @Autowired
    private UserService userService;
    @Autowired
    private BookingController bookingController;
    
    @GetMapping("/moveToSelectSeat")
    public String moveToSelectSeat(@RequestParam("routeId")Route route,
    					@RequestParam("date") 
    					@DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
    								Model model)
    {
    	model.addAttribute("route", route);
    	model.addAttribute("date",date);
    	bookingController.setBookingList(route.getId(), date, model);
    	return "moveToSelectSeat";
    }
     
    @GetMapping("/bookseat")
    public String bookseat(
            @RequestParam("bookingDate") Date bookingDate, 
            @RequestParam("seatNumber") String seatNumber,  
            @RequestParam("routeId") int routeId,                  
            Model model
    ) {
        model.addAttribute("seatNumber", seatNumber);
        model.addAttribute("routeId", routeId);
        model.addAttribute("date", bookingDate);
        List<User> userList= userService.findAllUsers();
        model.addAttribute("userList",userList);

//        System.out.println("Booking Date: " + bookingDate); // Debugging output
      for (User user2 : userList) {
		System.out.println(user2.getName());
	}
       
        return "bookseat"; // Return the JSP view
    }
    
    @GetMapping("/bookSeatByUser")
    public String bookSeatByUser(
            @RequestParam("bookingDate") Date bookingDate, 
            @RequestParam("seatNumber") String seatNumber,  
            @RequestParam("routeId") int routeId,                  
            Model model
    ) {
        model.addAttribute("seatNumber", seatNumber);
        model.addAttribute("routeId", routeId);
        model.addAttribute("date", bookingDate);
        List<User> userList= userService.findAllUsers();
        model.addAttribute("userList",userList);

//        System.out.println("Booking Date: " + bookingDate); // Debugging output
      for (User user2 : userList) {
		System.out.println(user2.getName());
	}
       
        return "registerUserPage"; // Return the JSP view
    }
    @GetMapping("/registerUserPage")
    public String getMethodName() {
        return "registerUserPage";
    }
    @PostMapping("/registerUserPageForm")
    public String registerUserPageForm(@ModelAttribute("user")User user,
    									@RequestParam("seatNumber") String seatNumber,
    									@RequestParam("routeId") Route route,
    									@RequestParam("date") String date,
    									Model model) {
        User user1 = userService.addUser(user);
        if (user1!=null) {
			model.addAttribute("success","User registerd successfully");
		}
        model.addAttribute("user",user1);
        model.addAttribute("seatNumber",seatNumber);
        model.addAttribute("date",date);
        model.addAttribute("route",route);
        return "finalBooking";
    }
    @PostMapping("/applydateuserform")
    public String applydateuserform(@RequestParam("date") 
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
	@ModelAttribute("route") Route route,Model model) {
        
    	bookingController.applydateform(date, route, model);
        
        return "moveToSelectSeat";
    }
    
    @GetMapping("/loginUser")
    public String loginUser(@RequestParam("date") Date bookingDate, 
            @RequestParam("seatNumber") String seatNumber,  
            @RequestParam("routeId") int routeId,                  
            Model model) {
    	model.addAttribute("seatNumber", seatNumber);
        model.addAttribute("routeId", routeId);
        model.addAttribute("date", bookingDate);
    	
        return "loginUser";
    }
//    @GetMapping("/loginUser")
//    public String loginUser() {
//    	
//        return "loginUser";
//    }
    @PostMapping("/loginUserForm")
    public String loginUserForm(@ModelAttribute("user")User user,
			@RequestParam("seatNumber") String seatNumber,
			@RequestParam("routeId") Route route,
			@RequestParam("date") String date,
			Model model) {
    	User user1=userService.findValidUser(user.getMobile(),user.getPassword());
        if (user1!=null) {
        	model.addAttribute("user",user1);
            model.addAttribute("seatNumber",seatNumber);
            model.addAttribute("date",date);
            model.addAttribute("route",route);
            model.addAttribute("success","user login success");
            return "finalBooking";
		}
        model.addAttribute("error","mobile or password is incorrect");
        return "loginUser";
    }
//    @PostMapping("/loginUserForm")
//    public String loginUserForm(@ModelAttribute("user")User user, Model model,HttpSession session) {
//    	User user1=userService.findValidUser(user.getMobile(),user.getPassword());
//        if (user1!=null) {
//        	session.setAttribute("userLogedIn", user1);
//            model.addAttribute("success","user login success");
//            return "/";
//		}
//        model.addAttribute("error","mobile or password is incorrect");
//        return "loginUser";
//    }
    
    
}
	