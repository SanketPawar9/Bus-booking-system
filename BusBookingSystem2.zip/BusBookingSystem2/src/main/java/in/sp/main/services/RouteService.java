package in.sp.main.services;

import java.util.List;

import in.sp.main.entitys.Route;

public interface RouteService {
	
	public boolean addRoute(Route route);
	public List<Route> getAllData();
	public Route getRouteById(int routeId);
	public List<Route> getAllActiveData();
	public List<Route> getAllInActiveData();
	public boolean updateStatus(Route route);
	

}
