package in.sp.main.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import in.sp.main.entitys.Admin;
import in.sp.main.entitys.Route;
import in.sp.main.services.AdminService;
import in.sp.main.services.RouteService;
import jakarta.servlet.http.HttpSession;


@Controller
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private RouteService routeService;
	
	@GetMapping("/loginpag")
	public String Login(Model model)
	{
		model.addAttribute("admin",new Admin());
		return "login";
	}
	
	@PostMapping("/loginForm")
	public String subLoginForm(@ModelAttribute("admin") Admin admin,Model model,HttpSession session)
	{
		 Admin validAdmin=adminService.loginUser(admin.getEmail(), admin.getPassword());
		 List<Route> route=routeService.getAllData();
		 
		 if (validAdmin!=null) {
			 //model.addAttribute("adminName",validAdmin.getName());
			 session.setAttribute("admin", validAdmin.getName());
			 model.addAttribute("route", route);
			 
			 return "profile";
		}
		 else {
			 model.addAttribute("error","Email id or Password is wrong");
		}
		 return "login";
		
	}
	@GetMapping("/logoutpag")
	public String logout(HttpSession session) {
	    session.invalidate(); // Destroy session
	    return "login"; // Redirect to login page
	}

	
	
	
//	@GetMapping("/serchSourceDestination")
//	public String serchSourceDestination(@RequestParam("source") String inputSource,
//										@RequestParam("destination") String inputDestination,
//										Model model)
//	{
//		List<Route> routes = routeService.getAllActiveData();
//		List<Route> routesList=new ArrayList<>();
//		List<String> sourceList=new ArrayList<>();
//		List<String> destinationList=new ArrayList<>();
//		
//		for (Route route : routes) {
//			String source = route.getSource().replaceAll("\\s*→\\s*", "→");
//		    String sourceWord = "";  // Initialize outside loop
//		    String destination = route.getDestination().replaceAll("\\s*→\\s*", "→");
//		    String destinationWord = "";
//		    
//		    for (int i = 0; i < source.length(); i++) {  
//		        if (source.charAt(i) == '→') {
//		            
//		                System.out.println(sourceWord); 
//		                sourceList.add(sourceWord);
//		            
//		            sourceWord = "";  // Reset word for the next segment
//		        } else {
//		        	sourceWord += source.charAt(i);  
//		        }
//		    }
//
//		    // Print the last word (if it exists) **BEFORE LOOP ENDS**
//		    if (!sourceWord.isEmpty()) {
//		        System.out.println(sourceWord);
//		        sourceList.add(sourceWord);
//		    }
//		   
//		    for (int i = 0; i < destination.length(); i++) {  
//		        if (destination.charAt(i) == '→') {
//		           
//		                System.out.println(destinationWord);
//		                destinationList.add(destinationWord);
//		                destinationWord = "";  // Reset word for the next segment
//		        } else {
//		        	destinationWord += destination.charAt(i);  
//		        }
//		    }
//
//		   
//		    if (!destinationWord.isEmpty()) {
//		        System.out.println(destinationWord);
//		        destinationList.add(destinationWord);
//		    }
//		    if (sourceList.contains(inputSource) && destinationList.contains(inputDestination)) {
//				
//		    	routesList.add(route);
//			}
//		    else {
//				sourceList.removeAll(sourceList);
//				destinationList.removeAll(destinationList);
//			}
//		    System.out.println("=============================");
//		    
//		}
//		model.addAttribute("routesList", routesList);
//		indexPage(model);
//		return "index";
//	}
	
	
	
}
