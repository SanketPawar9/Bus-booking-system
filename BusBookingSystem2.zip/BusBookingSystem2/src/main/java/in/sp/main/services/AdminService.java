package in.sp.main.services;

import in.sp.main.entitys.Admin;


public interface AdminService {

	Admin loginUser(String email, String password);

}
