package in.sp.main.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.sp.main.Repositories.UserRepository;
import in.sp.main.entitys.User;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;

	@Override
	public User addUser(User user) {
		User user1;
		try {
			user1=userRepository.save(user);
			return user1;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<User> findAllUsers() {
		List<User> a=userRepository.findAll();
		
		return a;
	}

	@Override
	public User findValidUser(String mobile, String password) {
		User user=null;
		try {
			 user=userRepository.findByMobileAndPassword(mobile,password);
		if (user!=null) {
			return user;
		}
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		return user;
	}
	

}
