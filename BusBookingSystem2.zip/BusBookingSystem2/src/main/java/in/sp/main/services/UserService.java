package in.sp.main.services;

import java.util.List;

import in.sp.main.entitys.User;

public interface UserService {
	
	public User addUser(User user);

	public List<User> findAllUsers();

	public User findValidUser(String mobile, String password);
	
}
