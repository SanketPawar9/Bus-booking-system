package in.sp.main.Repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import in.sp.main.entitys.Admin;





public interface AdminRepository extends JpaRepository<Admin, Integer> {

	Admin findByEmail(String email);

	
	
	

}
