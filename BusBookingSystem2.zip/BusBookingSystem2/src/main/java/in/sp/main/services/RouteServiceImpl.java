package in.sp.main.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import in.sp.main.Repositories.RouteRepository;
import in.sp.main.entitys.Route;

@Service
public class RouteServiceImpl implements RouteService {

	@Autowired
	private RouteRepository routeRepository;
	@Override
	public boolean addRoute(Route route) {
		try {
			routeRepository.save(route);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		
	}
	
	@Override
	public List<Route> getAllData() {
			
			return routeRepository.findAll();
	}

	@Override
	public Route getRouteById(int id) {
	    return routeRepository.findById(id).orElse(null);
	}

	@Override
	public List<Route> getAllActiveData() {

		
		return routeRepository.findByStatus("active");
	}

	@Override
	public List<Route> getAllInActiveData() {
		
		return routeRepository.findByStatus("inActive");
	}

	@Override
	public boolean updateStatus(Route route) {
		try {
			routeRepository.save(route);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	

}
