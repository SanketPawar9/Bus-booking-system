	package in.sp.main.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.sp.main.Repositories.AdminRepository;
import in.sp.main.entitys.Admin;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminRepository adminRepository;
	
	@Override
	public Admin loginUser(String email, String password) {
		Admin admin=adminRepository.findByEmail(email);
		if (admin.getEmail()!=null && admin.getPassword().equals(password)) {
			return admin;
		} 
		return null;
	}

}
