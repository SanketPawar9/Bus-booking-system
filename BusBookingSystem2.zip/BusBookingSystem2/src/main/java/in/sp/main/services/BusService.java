package in.sp.main.services;


import in.sp.main.entitys.Bus;

public interface BusService {

	void saveBus(Bus bus);

	
}
