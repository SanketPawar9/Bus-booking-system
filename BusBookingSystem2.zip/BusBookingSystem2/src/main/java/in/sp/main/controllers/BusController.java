package in.sp.main.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.sp.main.entitys.Booking;
import in.sp.main.entitys.Bus;
import in.sp.main.entitys.Route;
import in.sp.main.entitys.User;
import in.sp.main.services.BusService;
import in.sp.main.services.RouteService;



@Controller
public class BusController {
	
	@Autowired
	private RouteService routeService;
	
	@Autowired
	private BusService busService;

	@GetMapping("/addbus")
	public String addBus(Model model) {
		model.addAttribute("bus", new Bus());
		List<Route> routeData=routeService.getAllData();
		
		model.addAttribute("routeData",routeData);
		return "addbus";
	}
	
//	@PostMapping("/addbusform")
//	public String addBusForm(@ModelAttribute("bus") Bus bus, Model model)
//	{
//		System.out.println(bus.getBusName());
//		System.out.println(bus.getRoute());
//		return "profile";
//	}
	@PostMapping("/addbusform")
	public String addBusForm(@ModelAttribute("bus") Bus bus, @RequestParam("route_id") int routeId, Model model) {
	    // Fetch the route object from the database
	    Route route = routeService.getRouteById(routeId);
	    
	    // Set the route in the bus entity
	    bus.setRoute(route);

	    // Debugging outputs
	    System.out.println("Bus Name: " + bus.getBusName());
	    System.out.println("Bus Route: " + bus.getRoute().getSource() + " to " + bus.getRoute().getDestination());
	    System.out.println("Bus id: " + bus.getRoute().getId());
	    // You can now save the bus entity if needed
	     busService.saveBus(bus);

	    return "profile"; // Redirect to profile page
	}
	
	

	
}
