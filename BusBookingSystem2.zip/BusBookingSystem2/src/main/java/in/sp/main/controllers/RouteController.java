package in.sp.main.controllers;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import in.sp.main.entitys.Route;
import in.sp.main.services.RouteService;
import jakarta.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class RouteController {

	@Autowired
	private RouteService routeService;
	
	private void setDataInModel(Model model) {
		List<Route> route1=routeService.getAllActiveData();
		 model.addAttribute("route", route1);
		 
		 
		 List<Route> route2=routeService.getAllInActiveData();
		 model.addAttribute("inactiveRoute", route2);
		 
	}
	
	@GetMapping("/addroute")
	public String addroute(Model model)
	{
		model.addAttribute("route",new Route());
		return "addroute";
	}
	@PostMapping("/addrouteform")
	public String addRouteForm(@ModelAttribute("route") Route route,Model model,HttpSession session) {
		
		boolean status=routeService.addRoute(route);
		if (status) {
			model.addAttribute("success", "Route added succesfull");
		} else {
			model.addAttribute("error", "Route not added");
		}

		setDataInModel(model);
		 
		return "profile";
	}

	@GetMapping("/removeRoute")
	public String removeRoute(@RequestParam("routeId") Route route, Model model) {
	    
		route.setStatus("inActive");
		boolean status=routeService.updateStatus(route);
		if (status) {
			model.addAttribute("success","Route removed successfully");
		}
		else {
			model.addAttribute("error","Route not removed");
		}
		
		 setDataInModel(model);
	    return "profile";  
	}
	
	@GetMapping("/activateRoute")
	public String activateRoute(@RequestParam("inactiveRouteId") Route route,Model model) {
		route.setStatus("active");
		boolean status=routeService.updateStatus(route);
		if (status) {
			model.addAttribute("success","Route removed successfully");
		}
		else {
			model.addAttribute("error","Route not removed");
		}
		 setDataInModel(model);
		
		
		 return "profile";
	}
	
	
	
	
}
