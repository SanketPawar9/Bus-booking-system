package in.sp.main.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import in.sp.main.entitys.Bus;

public interface BusRepository extends JpaRepository<Bus, Integer>{

}
