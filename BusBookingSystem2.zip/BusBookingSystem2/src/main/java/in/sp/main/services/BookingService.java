package in.sp.main.services;

import java.time.LocalDate;
import java.util.List;

import in.sp.main.entitys.Booking;
import in.sp.main.entitys.Route;
import in.sp.main.entitys.User;

public interface BookingService {

	Booking addBooking(Booking booking);

	List<Booking> getBookingByDate(LocalDate currentDate, Route route);

	
	public boolean deleteBooking(Booking booking);

	List<Booking> findUserBookings(User user);

	

}
