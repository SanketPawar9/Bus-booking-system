package in.sp.main.Repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import in.sp.main.entitys.Booking;
import in.sp.main.entitys.Route;
import in.sp.main.entitys.User;


public interface BookingRepository extends JpaRepository<Booking, Integer> {



	List<Booking> findByBookingDateAndRoute(LocalDate bookingDate, Route route);
	List<Booking> findByUser(User user);
	 
	
}
