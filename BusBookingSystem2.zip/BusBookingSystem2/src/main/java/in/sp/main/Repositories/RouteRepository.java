package in.sp.main.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import in.sp.main.entitys.Route;
import java.util.List;





public interface RouteRepository extends JpaRepository<Route, Integer> {

	//Route save(Route route);

	List<Route> findByStatus(String status);
	
	
	
	
	

}
