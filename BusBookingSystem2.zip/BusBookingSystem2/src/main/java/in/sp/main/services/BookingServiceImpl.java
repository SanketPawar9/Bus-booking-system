package in.sp.main.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.sp.main.Repositories.BookingRepository;
import in.sp.main.entitys.Booking;
import in.sp.main.entitys.Route;
import in.sp.main.entitys.User;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	private BookingRepository bookingRepository;
	@Override
	public Booking addBooking(Booking booking) {
		Booking booking2=null;
		try {
			 booking2= bookingRepository.save(booking);
			
			return booking2;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return booking2;
	}
	@Override
	public List<Booking> getBookingByDate(LocalDate currentDate, Route route) {
		

		return bookingRepository.findByBookingDateAndRoute(currentDate, route);
	}
	@Override
	public boolean deleteBooking(Booking booking) {
		try {
			bookingRepository.delete(booking);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public List<Booking> findUserBookings(User user) {

		
		return bookingRepository.findByUser(user);
	}
	

	
	
	

}
